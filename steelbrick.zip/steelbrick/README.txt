To run application must install flask first:
	-Can do that with pip install flask

Then run python app.py

Load 'localhost:5000/invoice' in your browser

Have fun!
